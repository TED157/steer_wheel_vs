#ifndef __UI_H__
#define __UI_H__




void UI(void const * argument);
void UISendTask(void const * argument);
#endif