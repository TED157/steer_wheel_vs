#ifndef __CANSENDTASK_H
#define __CANSENDTASK_H

#include "struct_typedef.h"

void CanSendTask(void const * argument);
extern uint32_t CMSCounter;

#endif